package com.example.service_product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
